package com.example.qlhtgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlhtGameApplicationTests {

    @Test
    void contextLoads() {
    }

}
