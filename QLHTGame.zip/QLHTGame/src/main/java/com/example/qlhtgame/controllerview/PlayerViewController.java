package com.example.qlhtgame.controllerview;

import com.example.qlhtgame.entity.Player;
import com.example.qlhtgame.service.PlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/players")
public class PlayerViewController {
    @Autowired
    private PlayerService playerService;

    @GetMapping
    public String listPlayers(Model model) {
        model.addAttribute("players", playerService.getAll());
        return "player/list"; // templates/player/list.html
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("player", new Player());
        return "player/add";
    }

    @PostMapping("/add")
    public String addPlayer(@ModelAttribute Player player) {
        playerService.create(player);
        return "redirect:/players";
    }

    @GetMapping("/ranking")
    public String ranking(Model model) {
        model.addAttribute("players", playerService.ranking());
        return "player/ranking";
    }

    @GetMapping("/lock/{id}")
    public String lockPlayer(@PathVariable Long id) {
        playerService.lockPlayer(id);
        return "redirect:/players";
    }
}
