package com.example.qlhtgame.repository;

import com.example.qlhtgame.entity.Match;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatchRepository extends JpaRepository<Match, Long> {
}

